package com.claim.sprintbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprintBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
